package com.ciicc.DBank;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DBankApplication {

	public static void main(String[] args) {
		SpringApplication.run(DBankApplication.class, args);
	}

}
